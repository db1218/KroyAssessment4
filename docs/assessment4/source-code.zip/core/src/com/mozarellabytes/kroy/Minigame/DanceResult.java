package com.mozarellabytes.kroy.Minigame;

/**
 * Possible results for DanceMoves
 */
public enum DanceResult {
    GREAT,
    GOOD,
    OKAY,
    EARLY,
    LATE,
    WRONG,
    MISSED
}
